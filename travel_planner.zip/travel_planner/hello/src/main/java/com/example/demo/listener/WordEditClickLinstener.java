package com.example.demo.listener;

public interface WordEditClickLinstener {

    void edit(int position);

    void delete(int position);
}
